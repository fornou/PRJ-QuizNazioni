package com.prette;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgettoQuizgeograficoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProgettoQuizgeograficoApplication.class, args);
	}

}
